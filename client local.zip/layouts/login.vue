<template>
  <v-app>
    <main>
        <nuxt />
    </main>
  </v-app>
</template>

<script>
export default {

}
</script>

<style>

</style>