<template>
  <v-item-group v-model="selected" mandatory>
    <v-row>
      <v-col v-for="(item, i) in products" :key="i" cols="12" value="id" md="4">
        <v-item v-slot="{ active, toggle }" :disabled="true">
          <!-- Para inhabilitar la demas opciones removi el evento  @click="toggle" de la imagen para activarlo de debe agregar nuevamente-->
          <!-- Tambien agregue v-show="!item.disabled" en el btn, remover para el correcto funcionamiento-->
          <!-- Tambien cambiar el src de las iamgenes que desee habilitar-->
          <v-img
            :src="`${item.src}`"
            :class="active && !item.disabled ? 'text-center pa-2 product card_product' : 'text-center pa-2 product'"
            :disabled="true"
          >
            <v-btn icon dark v-show="!item.disabled" @click="toggle">
              <v-icon color="info" size="50" class="mt-7">
                {{ active ? "mdi-check-circle" : "" }}
              </v-icon>
            </v-btn>
          </v-img>
        </v-item>
      </v-col>
    </v-row>
  </v-item-group>
</template>

<script>
  export default {
    data: () => ({
      products: [
        {
          id: 1,
          src: "ketchup.png",
          disabled: false
        },
        {
          id: 2,
          src: "mayonesa_grey_scale.png",
          disabled: true
        },
        {
          id: 3,
          src: "mostaza_grey_scale.png",
          disabled: true
        }
      ],
      selected: 0
    }),
    methods: {
      customToggle() {
        this.$emit("ProductId", this.products[this.selected]);
      }
    },
    watch: {
      selected() {
        this.customToggle();
      }
    }
  };
</script>

<style scoped>
  .product {
    height: 95px !important;
    width: 180px;
  }
  div:disabled {
    -webkit-filter: grayscale(100%); /* Safari 6.0 - 9.0 */
    filter: grayscale(100%);
  }
  .card_product {
    border: 3px solid rgb(56, 88, 251);
    border-radius: 5px;
  }
</style>
